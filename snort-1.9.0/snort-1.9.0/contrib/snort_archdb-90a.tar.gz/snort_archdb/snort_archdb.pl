#!/usr/bin/perl -w
#
# snort_archdb.pl
# Author: Carl Hughey <chughey@selenetix.com>
#
# Based on the snort_cleandb.pl script from
# Chris Green <cmg@uab.edu> 
#
# The archive functionality borrows heavily from several functions
# within the Analysis Console for Intrusion Databases (ACID) by
# Roman Danyliw <rdd@cert.org>, <roman@danyliw.com> 
# 
# 
#
# This script takes a date argument and optionally archives all
# information related to the events, or simply deletes them.
# Cleaning of ACID database info is also supported.
#
# I initially created this script to help automate support of our internal
# data collectors, but thought it may be of general interest.
#
# The script is currently in use with MySQL. It should be fairly easy to
# add Postgres support. Other databases will require DBD driver support
# and some tweakage.
#
#
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.


use strict;
use DBI;
use Getopt::Std;

# Protos
sub convert_time($);
sub get_sidcid_range($$$$);
sub delete_records($$$);
sub parse_args(%);
sub db_connect(%$);
sub safe_exit($);
sub usage();
sub get_db_version($);
sub archive_records($$$$);
sub sql_fixup($$$);
sub debug_sqlret(@);
sub sqlret_fixup($$);
sub opt_db();

# Globals
my ($debug, $mysql_socket, %mincid, %maxcid, $sid, $do_acid, $safe_mode,
    $global_driver, $do_optimize, $tdate, $dbh, $dbh_arch, %args, $MYDCMD,
    $start_time, $db_version, $num_events, @tables, $DCMD, $HOST );

my ($VERSION) = ".90a";


##############################################################################
# Tweakables
##############################################################################

# Safe mode
# All deletions are simulated by doing SELECTS
# and dumping output. 
$safe_mode = 0;

# Debugging output
# Force on here or use -D on command line
$debug = 0;

# For MySQL "hide the socket" games
$mysql_socket="/var/lib/mysql/mysql.sock";

# Optimize db after delete/archive
# Currently only support for MySQL
# Force on here or use -o on command line
$do_optimize = 0;

# Define to clean ACID tables
# Force on here or use -a on command line
$do_acid = 0;

# Location of date command and desired format for logging
# Look at date manpage for format info
$DCMD="/bin/date";
$MYDCMD="$DCMD +\"%H:%M:%S\"";

# Location of hostname command
$HOST=`/bin/hostname`;
chop($HOST);


##############################################################################
# Main routine
##############################################################################

# Read command line
parse_args(\%args);

#Unbuffer output for debugging...
$| = 1;

$start_time=`$MYDCMD`;
print "\nsnort_archdb.pl version $VERSION\n\n";
print "Starting run on host [$HOST] at $start_time";

print "\n";

# Take user input and massage into native db DATETIME format
print "Main: Converting user time into database DATETIME format...\n" 
      if $debug;
$tdate=convert_time($args{'T'});
if($tdate eq "") 
{
    print "Error converting time to internal database format. ".
          "Exit...(1)\n";
    exit(1);
}

#Handle ACID tables if requested to do so...
if($do_acid)
{
    print "Main: Looking at ACID tables too...\n" if $debug;
    @tables = qw( data icmphdr iphdr tcphdr udphdr 
                  opt acid_ag_alert acid_event event );
}
else
{
    print "Main: Looking at snort tables only...\n" if $debug;
    @tables = qw( data icmphdr iphdr tcphdr udphdr 
                  opt event );
}


# Connect to database(s)
print "Main: Connecting to database(s)...\n" if $debug;
$dbh = db_connect(\%args,0);
$dbh_arch = db_connect(\%args,1) if $args{'A'};

# Get Version of database
print "Main: Checking version of snort database...\n" if $debug;
$db_version = get_db_version($dbh);

# Get list of sid-min/max(cid) for each sensor in database
print "Main: Getting list of sensor ids and max event ids...\n" 
      if $debug;
get_sidcid_range($dbh,$tdate,\%mincid,\%maxcid);

# Do the work...
if($args{'A'})
{
    $num_events=archive_records($dbh,$dbh_arch,\%mincid,\%maxcid);
    print "\n[".$num_events."] individual events found and archived.\n\n";
}
else 
{
    $num_events=delete_records($dbh,\%mincid,\%maxcid);
    print "\n[".$num_events."] individual events found and deleted.\n\n";
}

# Optimize db
opt_db() if($do_optimize);

# Bye
print "Ending run at : " . `$MYDCMD`;
print "Start time was: $start_time\n";
safe_exit(0);



##############################################################################
# Subroutines
##############################################################################


# convert_time($)
# takes 1 arguments
# usertime - date/time user entered
# returns scalar DATETIME format for database or empty string on error
sub convert_time($)
{
    my ($usertime) = @_;
    my $tdate="";

    print "Threshold time [$usertime]. ";

    # Take user ionput and massage into mySQL DATETIME format
    if($global_driver eq "mysql")
    {
        # There's probably some perl module that'll do this.
        $tdate=`$DCMD +"%Y-%m-%d %H:%M:%S" --date="$args{'T'}"`;
        print "Translated DATETIME ---> $tdate\n";
    }

    # Other coversions for other databases if necessary here...

    return $tdate;
}


# get_sidcid_range($$$$)
# takes 4 arguments
# dbh - database connection
# tdate - converted target date as delete/archive point
# ref_mincid - ref to global mincid array
# ref_maxcid - ref to global maxcid array
sub get_sidcid_range($$$$)
{
    my ($dbh, $tdate, $ref_mincid, $ref_maxcid) = @_;
    my ($q, $sid, $sql_cmd, @row, @sensors);

    # Get lists of sensors (sids)...
    print "get_sidcid_range: Getting list of sensors...\n" if $debug;
    $sql_cmd = "SELECT sid FROM sensor";
    $q = $dbh->prepare($sql_cmd);
    $q->execute() || die $dbh->errstr;

    unshift(@sensors, $row[0]) while(@row = $q->fetchrow_array);

    $q->finish();
    $q = undef;
    $sql_cmd = undef;

    # Find the min/max CID for each sensor we found using tdate as a limit
    print "get_sidcid_range: Getting list of min and max cids...\n" 
          if $debug;

    foreach $sid (@sensors)
    {
        $sql_cmd = "SELECT MIN(cid) FROM event ".
                   "WHERE sid=$sid AND timestamp<\'".
                   $tdate."\'";
        $q = $dbh->prepare($sql_cmd);
        $q->execute() || die $dbh->errstr;
        while(@row = $q->fetchrow_array)
        {
            ${$ref_mincid}{$sid}=$row[0] if $row[0];
	}
        $q->finish();
        $q = undef;
        $sql_cmd = undef;

        $sql_cmd = "SELECT MAX(cid) FROM event ".
                   "WHERE sid=$sid AND timestamp<\'".
                   $tdate."\'";
        $q = $dbh->prepare($sql_cmd);
        $q->execute() || die $dbh->errstr;
        while(@row = $q->fetchrow_array)
        {
            ${$ref_maxcid}{$sid}=$row[0] if $row[0];
	}
        $q->finish();
    }

    if($debug)
    {
        foreach $sid (keys %{$ref_maxcid})
        {
            print "Found sid: $sid		min(cid): ".
                  "${$ref_mincid}{$sid}		max(cid): ".
                  "${$ref_maxcid}{$sid} \n";
        }
    }
}


# delete_records($$$)
# takes 2 arguments
# dbh - database connection
# ref_maxcid - reference to global maxcid array
sub delete_records($$$) {
    my ($dbh, $ref_mincid, $ref_maxcid) = @_;
    my (%maxcid, $sql_cmd, $q, $table, $sid, $sidcol, 
        $cidcol, @row, $num_events);


    %mincid=%{$ref_mincid};
    %maxcid=%{$ref_maxcid};
    $num_events = 0;

    # Loop through sensors cleaning out tables...
    foreach $sid (keys %maxcid)
    {
        foreach $table (@tables)
        {
            $sidcol="sid";
            $cidcol="cid";

            # Acid specific tables use ag_ prefix on sid and cid
            if($table eq "acid_ag_alert")
            {
                $sidcol="ag_sid";
                $cidcol="ag_cid";
            }

            if($safe_mode)
            {
                print "\n---> Safe Mode is ON. SELECT records only.<---\n" if $debug;
	        $sql_cmd = "SELECT * ";
            }
            else
            {
	        $sql_cmd = "DELETE ";
            }

            if($mincid{$sid} == $maxcid{$sid})
            {
                print "\nStart single event delete operation: sensor [$sid], ".
                      "event id [$maxcid{$sid}], table [$table] at ". 
                      `$MYDCMD` if $debug;

	        $sql_cmd = $sql_cmd . "FROM $table WHERE $sidcol=$sid ".
                                      "AND $cidcol=$maxcid{$sid}";
            }
            else
            {
                print "\nStart multi event delete operation: sensor [$sid], ".
                      "min event id [$mincid{$sid}], ".
                      "max event id [$maxcid{$sid}], ".
                      "table [$table] at ". 
                      `$MYDCMD` if $debug;
             
                $sql_cmd = $sql_cmd . "FROM $table WHERE $sidcol=$sid ".
                                      "AND ($cidcol>=$mincid{$sid} AND ".
                                      "$cidcol<=$maxcid{$sid})";
            }

            print "delete_records: Executing SQL query [$sql_cmd] at ".
                  `$MYDCMD` if $debug;
	    $q = $dbh->prepare($sql_cmd);
	    $q->execute() || die $dbh->errstr;
            print "[".$q->rows()."] rows affected on last operation\n" 
                  if $debug;

            $num_events+=$q->rows() if($table eq "event");

            if($safe_mode)
            {
                while(@row = $q->fetchrow_array)
                {
                    print shift(@row) . " " while(@row);
                    print "\n";
                }
            }

            print "delete_records: Finishing SQL query [$sql_cmd] at ".
                  `$MYDCMD` . "\n\n" if $debug;
	    $q->finish();
	    $q = undef;
	    $sql_cmd = undef;
        }
    }

    return $num_events;
}


# parse_args(%)
# takes 1 argument
# args - reference to global args array
sub parse_args(%)
{
    my $args = shift;

    # Check to make sure the options are sane...
    getopts('oA:T:d:h:p:P:u:t:Das', $args);
    unless($args{'T'})
    {
	usage() && exit 1;
    }

    $debug=1 if $args{'D'} ;
    $do_acid=1 if $args{'a'} ;
    $safe_mode=1 if $args{'s'} ;
    $do_optimize=1 if $args{'o'} ;
    $global_driver =  $args{'t'} || "mysql";
}


# db_connect(%$)
# takes 2 arguments
# a - reference to global args array
# flag - 0 = return main database handle
#        1 = return archive database handle
sub db_connect(%$) {
    my $a = shift;
    my %args = %{$a};
    my $flag = shift;

    my ($database, $user, $password, $c_str, $dbh);

    $user = $args{'u'} || "";
    $password = $args{'P'} || "";

    # If we set flag, open up the archive database
    if($flag)
    {
        $database = $args{'A'};    
        print "Using database ".
              "[$database] for record archival.\n";
    }
    else
    {
        $database = "snort" || $args{'d'};    
        print "Using database ".
              "[$database] for snort events.\n";
    }

    $c_str = "dbi:$global_driver:dbname=$database;";
    $c_str .= "host=$args{'h'};" if $args{'h'};
    $c_str .= "port=$args{'p'};" if $args{'p'};
    if(($global_driver eq "mysql") && (!$args{'h'}))
    {
        $c_str .= "mysql_socket=$mysql_socket;";
    }

    $dbh = DBI->connect($c_str, $user, $password,{ PrintError => 0 })
      || die " Database connection not made: $DBI::errstr";

    return $dbh;
}


# safe_exit($)
# takes 1 argument
# exit_value - exit value reported to OS
sub safe_exit($)
{
    my $exit_val = shift;

    # Do cleanup...
    $dbh->disconnect() if($dbh);
    $dbh_arch->disconnect() if($dbh_arch);

    exit $exit_val;
}


# usage()
sub usage()
{
    print <<"EOF";

Usage:
    snort_archdb.pl -T date/time [ -s ] [ -u dbuser ] [ -P passwd ]
	[ -h hostname ] [ -d dbname ] [ -p port ] [ -t dbtype ]
	[ -D ] [ -A archdbname ] [ -o ] [ -a ]

-D		Turn on debugging output.

-s              Safe mode. Delete operations are not actually
                performed. Info that WOULD be deleted is dumped
                to stdout. When archiving, events are copied
                to the archive database, but not deleted from
                the main database. Use for testing.

-A archdbname	Archive records before deletion. Give name of archive database.
                In order for this to work, the archive database must be
                set up in advance with the snort schema and have the same
                user access privileges as the main snort database.
                It is recommended you rebuild the ACID event cache
                on the archive database after event archival.

-T date/time	Events OLDER than this date/time are deleted/archived.
		Refer to "--date" entry options in date man page.
		Options such as "1 month ago" or "3 weeks ago" are allowed.
                Use quotes to protect white space on the command line.

-d dbname       name of database to connect to ( defaults to 'snort' )
-h hostname     hostname of database ( defaults to local connection )
-u user         user to connect to database as
-p port         port to connect to (default is local connection)
-P password     password for database user  
-t dbtype	Database DBI driver type. (defaults to 'mysql')

-o		Optimize db after deletion/archiving (currently only for mysql)

-a              Delete records in ACID databases as well.
                If you use ACID with snort, you probably want to enable this
                option so the ACID tables are in sync with the snort tables.

EOF

}


# get_db_version($)
# takes 1 arguments
# dbh - database read connection
# returns database version
sub get_db_version($)
{
    my ($dbh) = @_;
    my ($sql_cmd, $q, @tmp_row);

    $sql_cmd = "SELECT vseq FROM schema";
    $sql_cmd = sql_fixup($sql_cmd,0,-1);
    $q = $dbh->prepare($sql_cmd);
    $q->execute() || die $dbh->errstr;
    @tmp_row = $q->fetchrow_array;
    $q->finish();
    $q = undef;
    $sql_cmd = undef;

    print "Snort schema: $tmp_row[0]\n" if $debug;

    return $tmp_row[0];
}


# archive_records($$$$)
# takes 4 arguments
# dbh - database read connection
# dbh_arch - database archive connection
# ref_mincid - reference to global mincid array
# ref_maxcid - reference to global maxcid array
# returns number of events handled
sub archive_records($$$$)
{
    my ($dbh, $dbh_arch, $ref_mincid, $ref_maxcid) = @_;
    my ($sql_cmd, $q, $q2, @tmp_row, @tmp_row2, @insert_sql, 
        $sql_cnt, $archive_cnt, $tmp_result, $sid, $cid,
        $sig, $timestamp, $sig_name, $sig_id, $sig_class_id,
        $sig_priority, $sig_rev, $sig_sid, $sig_class_name,
        $MAX_REF_CNT, @sig_reference, $sig_reference_cnt, 
        $ref_id, $ref_tag, $ref_system_name, $ref_system_id,
        $line, $ip_proto, $opt_cnt,
        $i, $j, @sig_id, $q_result,
        $sig_ref, %mincid, %maxcid, $table, $errstr,
        $num_events, $qrows );


    %mincid=%{$ref_mincid};
    %maxcid=%{$ref_maxcid};

    $num_events = 0 ;

    # Loop through sensors orchiving records...
    foreach $sid (keys %maxcid)
    {
        #for($cid = $mincid{$sid}; $cid <= $mincid{$sid}; $cid++) 
        for($cid = $mincid{$sid}; $cid <= $maxcid{$sid}; $cid++) 
        {
            print "archive_records: Begin archiving entries for sid ".
                  "[$sid] and event-id [$cid] at ".`$MYDCMD` if $debug;
            $sql_cnt = 0;
            $archive_cnt = 0;

            $sql_cmd = "SELECT hostname,interface,filter,detail,encoding ".
                       "FROM sensor WHERE sid=$sid";
            $sql_cmd = sql_fixup($sql_cmd,0,-1);
            $q = $dbh->prepare($sql_cmd);
            print "archive_records: Executing SQL ".
                  "[$sql_cmd]\n" if $debug;
            $q->execute() || die $dbh->errstr;
            $qrows=$q->rows();
            @tmp_row=$q->fetchrow_array;
            $q->finish();
            $q = undef;
            $sql_cmd = undef;

            if($qrows)
            {
                sqlret_fixup(\@tmp_row,4);
                $sql_cmd = "INSERT INTO sensor ".
                           "(sid,hostname,interface,filter,detail,encoding) ".
                           "VALUES ($sid,\'$tmp_row[0]\',\'$tmp_row[1]\',".
                           "\'$tmp_row[2]\',\'$tmp_row[3]\',\'$tmp_row[4]\')";
                $sql_cmd = sql_fixup($sql_cmd,0,-1);

                print "archive_records: Storing SQL ".
                      "[$sql_cmd]\n" if $debug;
                push(@insert_sql,$sql_cmd);
                $sql_cnt++;
            }
            @tmp_row = undef;

            $sql_cmd = "SELECT signature,timestamp FROM event ".
                       "WHERE sid=$sid AND cid=$cid";
            $sql_cmd = sql_fixup($sql_cmd,0,-1);
            $q = $dbh->prepare($sql_cmd);
            print "archive_records: Executing SQL ".
                  "[$sql_cmd]\n" if $debug;
            $q->execute() || die $dbh->errstr;
            $qrows=$q->rows();
            @tmp_row=$q->fetchrow_array;
            $q->finish();
            $q = undef;
            $sql_cmd = undef;

            if($qrows)
            {
                sqlret_fixup(\@tmp_row,1);

                $sig = $tmp_row[0];
                $timestamp = $tmp_row[1];
            }
            else
            {
                $sig = "";
                $timestamp = "";
            }
            @tmp_row = undef;

            $sig_name = "";
            if($db_version < 100 )
            {
                $sql_cmd = "INSERT INTO event ".
                           "(sid,cid,signature,timestamp) ".
                           "VALUES ($sid,$cid,\'$sig\',\'$timestamp\')"; 
                $sql_cmd = sql_fixup($sql_cmd,0,-1);
                print "archive_records: Storing SQL ".
                      "[$sql_cmd]\n" if $debug;
                push(@insert_sql,$sql_cmd);
                $sql_cnt++;
            }
            # Catch alerts with a null signature 
            # (e.g. with use of tag rule option)
            elsif($sig ne "")
            {
                $sql_cmd = "SELECT sig_name FROM signature ".
                           "WHERE sig_id=$sig";
                $sql_cmd = sql_fixup($sql_cmd,0,-1);
                $q = $dbh->prepare($sql_cmd);
                print "archive_records: Executing SQL ".
                      "[$sql_cmd]\n" if $debug;
                $q->execute() || die $dbh->errstr;
                @tmp_row=$q->fetchrow_array;
                $q->finish();
                $q = undef;
                $sql_cmd = undef;

                sqlret_fixup(\@tmp_row,0);

                if($tmp_row[0] ne "")
                {
                    $sig_name = $tmp_row[0];
                }
                else 
                {
                    $sig_name = "[SigName unknown]";
                }
                @tmp_row = undef;

                if($db_version >= 103 )
                {
                    $sql_cmd = "SELECT sig_class_id,sig_priority,".
                               "sig_rev,sig_sid FROM signature ".
                               "WHERE sig_id=$sig";
                    $sql_cmd = sql_fixup($sql_cmd,0,-1);
                    $q = $dbh->prepare($sql_cmd);
                    print "archive_records: Executing SQL ".
                          "[$sql_cmd]\n" if $debug;
                    $q->execute() || die $dbh->errstr;
                    $qrows=$q->rows();
                    @tmp_row=$q->fetchrow_array;
                    $sql_cmd = undef;
                    $q->finish();
                    $q = undef;

                    if($qrows)
                    {
                        sqlret_fixup(\@tmp_row,3);

                        $sig_class_id = $tmp_row[0];
                        $sig_priority = $tmp_row[1];
                        $sig_rev = $tmp_row[2];
                        $sig_sid = $tmp_row[3];
                    }
                    else
                    {
                        $sig_class_id = "";
                        $sig_priority = "";
                        $sig_rev = "";
                        $sig_sid = "";
                    }
                    @tmp_row = undef;

                    if($sig_class_id eq "") 
                    {
                        $sig_class_name = "<I>unclassified</I>";
                    }
                    else
                    {
                        $sql_cmd = "SELECT sig_class_name FROM sig_class ".
                                   "WHERE sig_class_id = $sig_class_id";
                        $sql_cmd = sql_fixup($sql_cmd,0,-1);
                        $q = $dbh->prepare($sql_cmd);
                        print "archive_records: Executing SQL ".
                              "[$sql_cmd]\n" if $debug;
                        $q->execute() || die $dbh->errstr;
                        @tmp_row=$q->fetchrow_array;
                        $q->finish();
                        $q = undef;
                        $sql_cmd = undef;

                        sqlret_fixup(\@tmp_row,0);

                        if($tmp_row[0] eq "")
                        {
                            $sig_class_name = "<I>unclassified</I>";
                        }
                        else
                        {
                            $sig_class_name = $tmp_row[0];
                        }
                        @tmp_row = undef;
                    }
                }

                $MAX_REF_CNT = 6;
                @sig_reference = undef;
                $sig_reference_cnt = 0;

                $sql_cmd = "SELECT ref_id FROM sig_reference ".
                           "WHERE sig_id=$sig";
                $sql_cmd = sql_fixup($sql_cmd,0,-1);
                $q = $dbh->prepare($sql_cmd);
                print "archive_records: Executing SQL ".
                      "[$sql_cmd]\n" if $debug;
                $q->execute() || die $dbh->errstr;
                $sql_cmd = undef;
 
                while ( (@tmp_row = $q->fetchrow_array) &&
                        ($sig_reference_cnt < $MAX_REF_CNT) )
                {
                    sqlret_fixup(\@tmp_row,0);

                    $ref_id = $tmp_row[0];

                    $sql_cmd = "SELECT ref_system_id,ref_tag ".
                               "FROM reference WHERE ref_id=$ref_id";
                    $sql_cmd = sql_fixup($sql_cmd,0,-1);
                    $q2 = $dbh->prepare($sql_cmd);
                    print "archive_records: Executing SQL ".
                          "[$sql_cmd]\n" if $debug;
                    $q2->execute() || die $dbh->errstr;
                    @tmp_row2=$q2->fetchrow_array;
                    $q2->finish();
                    $q2 = undef;
                    $sql_cmd = undef;

                    sqlret_fixup(\@tmp_row2,0);

                    $ref_system_name = "";
                    if($tmp_row2[0] ne "")
                    {
                        $ref_system_id = $tmp_row2[0];
                        $ref_tag = $tmp_row2[1];
                        @tmp_row2 = undef;

                        $sql_cmd = "SELECT ref_system_name ".
                                   "FROM reference_system ".
                                   "WHERE ref_system_id=$ref_system_id";
                        $sql_cmd = sql_fixup($sql_cmd,0,-1);
                        $q2 = $dbh->prepare($sql_cmd);
                        print "archive_records: Executing SQL ".
                              "[$sql_cmd]\n" if $debug;
                        $q2->execute() || die $dbh->errstr;
                        @tmp_row2=$q2->fetchrow_array;
                        $q2->finish();
                        $q2 = undef;
                        $sql_cmd = undef;

                        sqlret_fixup(\@tmp_row2,0);

                        if($tmp_row2[0] ne "")
                        {
                            $ref_system_name = $tmp_row2[0];
                        }
                        @tmp_row2 = undef;
                    }
                    @tmp_row2 = undef;

                    unshift(@sig_reference, 
                            [ $ref_system_id,$ref_tag,$ref_system_name ] );
                    $sig_reference_cnt++;
                }
                $q->finish();
                $q = undef;
                @tmp_row = undef;
            }

            $sql_cmd = "SELECT ip_src,ip_dst,ip_ver,ip_hlen,".
                       "ip_tos,ip_len,ip_id,ip_flags,ip_off,".
                       "ip_ttl,ip_proto,ip_csum FROM iphdr ".
                       "WHERE sid=$sid AND cid=$cid";
            $sql_cmd = sql_fixup($sql_cmd,0,-1);
            $q = $dbh->prepare($sql_cmd);
            print "archive_records: Executing SQL ".
                  "[$sql_cmd]\n" if $debug;
            $q->execute() || die $dbh->errstr;
            $qrows=$q->rows();
            @tmp_row=$q->fetchrow_array;
            $sql_cmd = undef;

            if($qrows)
            {
                sqlret_fixup(\@tmp_row,11);
                $sql_cmd = "INSERT INTO iphdr (sid,cid,ip_src,ip_dst,".
                           "ip_ver,ip_hlen,ip_tos,ip_len,ip_id,ip_flags,".
                           "ip_off,ip_ttl,ip_proto,ip_csum) VALUES ".
                           "($sid,$cid,\'$tmp_row[0]\',\'$tmp_row[1]\',".
                           "\'$tmp_row[2]\',\'$tmp_row[3]\',".
                           "\'$tmp_row[4]\',\'$tmp_row[5]\',".
                           "\'$tmp_row[6]\',\'$tmp_row[7]\',".
                           "\'$tmp_row[8]\',\'$tmp_row[9]\',".
                           "\'$tmp_row[10]\',\'$tmp_row[11]\')";
                $sql_cmd = sql_fixup($sql_cmd,0,-1);

                print "archive_records: Storing SQL ".
                      "[$sql_cmd]\n" if $debug;
                push(@insert_sql,$sql_cmd);
                $sql_cnt++;
                $sql_cmd = undef;

                $ip_proto = $tmp_row[10];
            }
            else
            {
                $ip_proto = "-1";
            }
            $q->finish();
            $q = undef;
            @tmp_row = undef;

            if($ip_proto eq "6")
            {
                $sql_cmd = "SELECT tcp_sport,tcp_dport,tcp_seq,".
                           "tcp_ack,tcp_off,tcp_res,tcp_flags,".
                           "tcp_win,tcp_csum,tcp_urp FROM tcphdr ".
                           "WHERE sid=$sid AND cid=$cid";
                $sql_cmd = sql_fixup($sql_cmd,0,-1);
                $q = $dbh->prepare($sql_cmd);
                print "archive_records: Executing SQL ".
                      "[$sql_cmd]\n" if $debug;
                $q->execute() || die $dbh->errstr;
                @tmp_row=$q->fetchrow_array;
                $qrows=$q->rows();
                $q->finish();
                $q = undef;
                $sql_cmd = undef;

                if($qrows)
                {
                    sqlret_fixup(\@tmp_row,9);

                    $sql_cmd = "INSERT INTO tcphdr (sid,cid,".
                               "tcp_sport,tcp_dport,tcp_seq,".
                               "tcp_ack,tcp_off,tcp_res,tcp_flags,".
                               "tcp_win,tcp_csum,tcp_urp) VALUES ".
                               "($sid,$cid,\'$tmp_row[0]\',".
                               "\'$tmp_row[1]\',\'$tmp_row[2]\',".
                               "\'$tmp_row[3]\',\'$tmp_row[4]\',".
                               "\'$tmp_row[5]\',\'$tmp_row[6]\',".
                               "\'$tmp_row[7]\',\'$tmp_row[8]\',".
                               "\'$tmp_row[9]\')";
                    $sql_cmd = sql_fixup($sql_cmd,0,-1);

                    print "archive_records: Storing SQL ".
                          "[$sql_cmd]\n" if $debug;
                    push(@insert_sql,$sql_cmd);
                    $sql_cnt++;
                    $sql_cmd = undef;
                }
                @tmp_row = undef;
            }
            elsif($ip_proto eq "17")
            {
                $sql_cmd = "SELECT udp_sport,udp_dport,udp_len,udp_csum ".
                           "FROM udphdr WHERE sid=$sid AND cid=$cid";
                $sql_cmd = sql_fixup($sql_cmd,0,-1);
                $q = $dbh->prepare($sql_cmd);
                print "archive_records: Executing SQL ".
                      "[$sql_cmd]\n" if $debug;
                $q->execute() || die $dbh->errstr;
                $qrows=$q->rows();
                @tmp_row=$q->fetchrow_array;
                $q->finish();
                $q = undef;
                $sql_cmd = undef;

                if($qrows)
                {
                    sqlret_fixup(\@tmp_row,3);

                    $sql_cmd = "INSERT INTO udphdr (sid,cid,udp_sport,".
                               "udp_dport,udp_len,udp_csum) VALUES ".
                               "($sid,$cid,\'$tmp_row[0]\',".
                               "\'$tmp_row[1]\',\'$tmp_row[2]\',".
                               "\'$tmp_row[3]\')";
                    $sql_cmd = sql_fixup($sql_cmd,0,-1);

                    print "archive_records: Storing SQL ".
                          "[$sql_cmd]\n" if $debug;
                    push(@insert_sql,$sql_cmd);
                    $sql_cnt++;
                    $sql_cmd = undef;
                }
                @tmp_row = undef;
            }
            elsif($ip_proto eq "1")
            {
                $sql_cmd = "SELECT icmp_type,icmp_code,icmp_csum,".
                           "icmp_id,icmp_seq FROM icmphdr WHERE ".
                           "sid=$sid AND cid=$cid";
                $sql_cmd = sql_fixup($sql_cmd,0,-1);
                $q = $dbh->prepare($sql_cmd);
                print "archive_records: Executing SQL ".
                      "[$sql_cmd]\n" if $debug;
                $q->execute() || die $dbh->errstr;
                $qrows=$q->rows();
                @tmp_row=$q->fetchrow_array;
                $q->finish();
                $q = undef;
                $sql_cmd = undef;

                if($qrows)
                {
                    sqlret_fixup(\@tmp_row,4);

                    $sql_cmd = "INSERT INTO icmphdr (sid,cid,icmp_type,".
                               "icmp_code,icmp_csum,icmp_id,icmp_seq) ".
                               "VALUES ($sid, $cid,\'$tmp_row[0]\',".
                               "\'$tmp_row[1]\',\'$tmp_row[2]\',".
                               "\'$tmp_row[3]\',\'$tmp_row[4]\')";
                    $sql_cmd = sql_fixup($sql_cmd,0,-1);

                    print "archive_records: Storing SQL ".
                          "[$sql_cmd]\n" if $debug;
                    push(@insert_sql,$sql_cmd);
                    $sql_cnt++;
                    $sql_cmd = undef;
                }
                @tmp_row = undef;
            }

            $sql_cmd = "SELECT data_payload FROM data ".
                       "WHERE sid=$sid AND cid=$cid";
            $sql_cmd = sql_fixup($sql_cmd,0,-1);
            $q = $dbh->prepare($sql_cmd);
            print "archive_records: Executing SQL ".
                  "[$sql_cmd]\n" if $debug;
            $q->execute() || die $dbh->errstr;
            @tmp_row=$q->fetchrow_array;
            $q->finish();
            $q = undef;
            $sql_cmd = undef;

            sqlret_fixup(\@tmp_row,0);

            if($tmp_row[0] ne "")
            {
                $sql_cmd = "INSERT INTO data (sid,cid,data_payload) VALUES ".
                           "($sid,$cid,\'$tmp_row[0]\')";
                $sql_cmd = sql_fixup($sql_cmd,0,-1);

                print "archive_records: Storing SQL ".
                      "[$sql_cmd]\n" if $debug;
                push(@insert_sql,$sql_cmd);
                $sql_cnt++;
                $sql_cmd = undef;
            }
            @tmp_row = undef;

            $opt_cnt = 0;
            $sql_cmd = "SELECT optid,opt_proto,opt_code,opt_len,opt_data ".
                       "FROM opt WHERE sid=$sid AND cid=$cid";
            $sql_cmd = sql_fixup($sql_cmd,0,-1);
            $q = $dbh->prepare($sql_cmd);
            print "archive_records: Executing SQL ".
                  "[$sql_cmd]\n" if $debug;
            $q->execute() || die $dbh->errstr;
            $sql_cmd = undef;

            while( (@tmp_row = $q->fetchrow_array) &&
                   ($opt_cnt < 19) )
            {
                sqlret_fixup(\@tmp_row,4);

                $sql_cmd = "INSERT INTO opt (sid,cid,optid,opt_proto,".
                           "opt_code,opt_len,opt_data) VALUES ".
                           "($sid,$cid,\'$tmp_row[0]\',\'$tmp_row[1]\',".
                           "\'$tmp_row[2]\',\'$tmp_row[3]\',".
                           "\'$tmp_row[4]\')";
                $sql_cmd = sql_fixup($sql_cmd,0,-1);

                print "archive_records: Storing SQL ".
                      "[$sql_cmd]\n" if $debug;
                push(@insert_sql,$sql_cmd);
                $sql_cnt++;
                $sql_cmd = undef;
                $opt_cnt++;
            }
            $q->finish();
            $q = undef;
            @tmp_row = undef;

            $archive_cnt = 0;

            # If signatures are normalized (schema v100+), then it is 
            # impossible to merely copy the event table completely.  Rather
            # the signatures must be written to the archive DB, and their
            # new ID must be written into the archived event table
            if($db_version >= 100)
            {
                # Check whether this signature already exists in
                # the archive DB.  If so, get the ID, otherwise first
                # write the signature into the archive DB, and then
                # get the newly inserted ID
                if($sig_name eq "")
                {
                    $sig_id = "";
                }
                else
                {
                    $sql_cmd = "SELECT sig_id FROM signature ".
                               "WHERE sig_name=\'$sig_name\'";
                    $sql_cmd = sql_fixup($sql_cmd,0,-1);
                    $q = $dbh_arch->prepare($sql_cmd);
                    print "archive_records: Executing SQL ".
                          "[$sql_cmd]\n" if $debug;
                    $q->execute() || die $dbh->errstr;
                    @tmp_row=$q->fetchrow_array;
                    $sql_cmd = undef;
                    $q->finish();
                    $q = undef;

                    sqlret_fixup(\@tmp_row,0);

                    if($tmp_row[0] ne "")
                    {
                        $sig_id = $tmp_row[0];
                    }
                    else
                    {
                        $sig_id = "";
                    }
                    @tmp_row = undef;
                }

                if(($sig_id eq "") && ($sig_name ne ""))
                {
                    if( $db_version >= 103 )
                    {
                        if( $sig_class_id eq "" )  
                        {
                            $sig_class_id = 'NULL';
                        }
                        else
                        {
                            # get the ID of the classification
                            $sql_cmd = "SELECT sig_class_id ".
                                       "FROM sig_class WHERE ".
                                       "sig_class_name = \'$sig_class_name\'";
                            $sql_cmd = sql_fixup($sql_cmd,0,-1);
                            $q = $dbh_arch->prepare($sql_cmd);
                            print "archive_records: Executing SQL ".
                                  "[$sql_cmd]\n" if $debug;
                            $q->execute() || die $dbh_arch->errstr;
                            @tmp_row=$q->fetchrow_array;
                            $q->finish();
                            $q = undef;
                            $sql_cmd = undef;

                            sqlret_fixup(\@tmp_row,0);

                            if($tmp_row[0] eq "")
                            {
                                $sql_cmd = "INSERT INTO sig_class ".
                                           "(sig_class_name) ".
                                           "VALUES (\'$sig_class_name\')";
                                $sql_cmd = sql_fixup($sql_cmd,0,-1);
                                $q = $dbh_arch->prepare($sql_cmd);
                                print "archive_records: Executing SQL ".
                                      "[$sql_cmd]\n" if $debug;
                                $q->execute() || die $dbh_arch->errstr;
                                $sql_cmd = undef;

                                if(($global_driver eq "mysql") || 
                                   ($global_driver eq "mysqlt"))
                                {
                                    $sig_class_id=$dbh_arch->{'mysql_insertid'};
                                }
                                $q->finish();
                                $q = undef;

                                # Other database Insert ID games here...
                            }
                            else
                            {
                                $sig_class_id = $tmp_row[0];
                            }
                            @tmp_row = undef;
                        }

                        $sig_priority = 'NULL' if($sig_priority eq "");
                   
                        $sql_cmd = "INSERT INTO signature (sig_name,".
                                   "sig_class_id,sig_priority,sig_rev,".
                                   "sig_sid) VALUES (\'$sig_name\',".
                                   "\'$sig_class_id\',\'$sig_priority\',".
                                   "\'$sig_rev\',\'$sig_sid\')";
                        $sql_cmd = sql_fixup($sql_cmd,0,-1);

                    }
                    else
                    {
                        $sql_cmd = "INSERT INTO signature (sig_name) ".
                                   "VALUES (\'$sig_name\')";
                        $sql_cmd = sql_fixup($sql_cmd,0,-1);
                    }

                    $q = $dbh_arch->prepare($sql_cmd);
                    print "archive_records: Executing SQL ".
                          "[$sql_cmd]\n" if $debug;
                    $q->execute() || die $dbh_arch->errstr;
                    $sql_cmd = undef;

                    # MySQL
                    if(($global_driver eq "mysql") || 
                       ($global_driver eq "mysqlt"))
                    {
                        $sig_id = $dbh_arch->{'mysql_insertid'};
                    }
                    # Other database Insert ID games here...

                    $q->finish();
                    $q = undef;
                }

                # add reference information
                for($j = 0;$j < $sig_reference_cnt;$j++)
                {
                    # get the ID of the reference system
                    $sql_cmd = "SELECT ref_system_id ".
                               "FROM reference_system ".
                               "WHERE ref_system_name = ".
                               "\'$sig_reference[$j][2]\'";
                    $sql_cmd = sql_fixup($sql_cmd,0,-1);
                    $q = $dbh_arch->prepare($sql_cmd);
                    print "archive_records: Executing SQL ".
                          "[$sql_cmd]\n" if $debug;
                    $q->execute() || die $dbh_arch->errstr;
                    @tmp_row=$q->fetchrow_array;
                    $q->finish();
                    $q = undef;
                    $sql_cmd = undef;

                    sqlret_fixup(\@tmp_row,0);

                    if($tmp_row[0] eq "")
                    {
                        $sql_cmd = "INSERT INTO reference_system ".
                                   "(ref_system_name) VALUES ".
                                   "(\'$sig_reference[$j][2]\')";
                        $sql_cmd = sql_fixup($sql_cmd,0,-1);
                        $q = $dbh_arch->prepare($sql_cmd);
                        print "archive_records: Executing SQL ".
                              "[$sql_cmd]\n" if $debug;
                        $q->execute() || die $dbh_arch->errstr;
                        $sql_cmd = undef;

                        if(($global_driver eq "mysql") || 
                           ($global_driver eq "mysqlt"))
                        {
                            $ref_system_id = $dbh_arch->{'mysql_insertid'};
                        }
                        # Other database Insert ID games here...

                        $q->finish();
                        $q = undef;
                    }
                    else
                    {
                        $ref_system_id = $tmp_row[0];
                    }
                    @tmp_row = undef;

                    $sql_cmd = "SELECT ref_id FROM reference WHERE ".
                               "ref_system_id=\'$ref_system_id\' AND ".
                               "ref_tag=\'$sig_reference[$j][1]\'";

                    $sql_cmd = sql_fixup($sql_cmd,0,-1);
                    $q = $dbh_arch->prepare($sql_cmd);
                    print "archive_records: Executing SQL ".
                          "[$sql_cmd]\n" if $debug;
                    $q->execute() || die $dbh_arch->errstr;
                    @tmp_row=$q->fetchrow_array;
                    $q->finish();
                    $q = undef;
                    $sql_cmd = undef;

                    sqlret_fixup(\@tmp_row,0);

                    if($tmp_row[0] ne "")
                    {
                        $ref_id = $tmp_row[0];
                    }
                    else
                    {
                        #$sql_cmd = "INSERT INTO reference (ref_system_id, ref_tag) ".
                        #           "VALUES (".$sig_reference[$j][0].",\'".$sig_reference[$j][1]."\')";
                        $sql_cmd = "INSERT INTO reference ".
                                   "(ref_system_id, ref_tag) ".
                                   "VALUES ($ref_system_id,".
                                   "\'$sig_reference[$j][1]\')";
                        $sql_cmd = sql_fixup($sql_cmd,0,-1);
                        $q = $dbh_arch->prepare($sql_cmd);

                        print "archive_records: Executing SQL ".
                              "[$sql_cmd]\n" if $debug;
                        $q->execute() || die $dbh_arch->errstr;
                        $sql_cmd = undef;

                        # $ref_id = $db2->acidInsertID(); 
                        if(($global_driver eq "mysql") || 
                           ($global_driver eq "mysqlt"))
                        {
                            $ref_id = $dbh_arch->{'mysql_insertid'};
                        }
                        # Other database Insert ID games here...

                        $q->finish();
                        $q = undef;
                    }        
                    @tmp_row = undef;

                    if(($ref_id ne "") && ($ref_id > 0))
                    {
                        $sql_cmd = "INSERT INTO sig_reference ".
                                   "(sig_id, ref_seq, ref_id) ".
                                   "VALUES ($sig_id,".($j+1).",$ref_id)";
                        $sql_cmd = sql_fixup($sql_cmd,0,-1);

                        print "archive_records: Storing SQL ".
                              "[$sql_cmd]\n" if $debug;
                        push(@insert_sql,$sql_cmd);
                        $sql_cnt++;
                        $sql_cmd = undef;
                    }

                } # End of foreach $sig_ref (@sig_reference)

                $sql_cmd = "INSERT INTO event ".
                           "(sid,cid,signature,timestamp) ".
                           "VALUES ($sid,$cid,\'$sig_id\',\'$timestamp\')";
                $sql_cmd = sql_fixup($sql_cmd,0,-1);

                print "archive_records: Storing SQL".
                      "[$sql_cmd]\n" if $debug;
                push(@insert_sql,$sql_cmd);
                $sql_cnt++;
                $sql_cmd = undef;
             
            } # End of if( $db_version >= 100 )

            # Write Alerts into archive database
            while(@insert_sql)
            {
                $sql_cmd = shift(@insert_sql);
                $q = $dbh_arch->prepare($sql_cmd);
                print "archive_records: Executing SQL".
                      "[$sql_cmd]\n" if $debug;
                $q_result = $q->execute();
		$errstr = $dbh_arch->errstr;
                print "error: [$errstr] " if($debug && $errstr);
                $q->finish();
                $q = undef;

                unless($errstr)
                {
                    ++$archive_cnt;
                }
                else
                {
                    # Sometimes INSERTs will be made for records which
                    # already exist (e.g. sensor or sig_reference table).
                    # When we get such an error, assume that this is ok
                    if( $sql_cmd =~ /INSERT INTO sensor/ ||
                        $sql_cmd =~ /INSERT INTO sig_reference/ ||
                        $sql_cmd =~ /SET IDENTITY_INSERT/ )
                    {
                        print "Allowed error. Continuing...\n\n" if $debug;
                        ++$archive_cnt;
                    }
                    else
                    { 
                        print "\nFatal database error: ".
                              "[$errstr] Bailing...\n";
                        safe_exit(1);
                    }
                }
            } # End of while(@insert_sql)

            # Check if all data was written to archive database
            # before purging the alert from the current database
            if($archive_cnt == $sql_cnt)
            {
                # Purgealert
                my %mycid;
		$mycid{$sid}=$cid;

                delete_records($dbh,\%mycid,\%mycid);
            }
            else
            {
                print "Error archiving record...Event has NOT been ".
                      "deleted from database. Aborting!\n";
                safe_exit(2);
            }

            print "archive_records: End archiving entries for sid ".
                  "[$sid] and event-id [$cid] at ".`$MYDCMD`.
                  "\n" if $debug;
            $num_events++;
        }
    }

    return $num_events;

}


sub sql_fixup($$$)
{
    my($sql_cmd, $start_row, $num_rows) = @_;

    $start_row=0 unless $start_row;
    $num_rows=-1 unless $num_rows;

    # ** Begin DB specific SQL fix-up **

    # ** Begin optimization SQL fix-up ** 
    $sql_cmd =~ s/acid_event\.sid > 0 AND //g;
    $sql_cmd =~ s/WHERE  acid_event\.sid > 0//g;

    # ** End SQL fix-up ** */

    my $limit_str = "";

    # Check whether need to add a LIMIT / TOP / ROWNUM clause
    if( $num_rows != -1 )
    {
        if ( ($global_driver eq "mysql") || 
             ($global_driver eq "mysqlt") )
        {
            $limit_str = " LIMIT ".$start_row.", ".$num_rows;
        }
        elsif ( $global_driver == "Pg" )
        {
            $limit_str = " LIMIT ".$num_rows." OFFSET ".$start_row;
        }

        # Other database limit stuff here

        # Append LIMIT stuff to query string
        $sql_cmd = $sql_cmd . $limit_str;
    }

    return $sql_cmd;
}


sub sqlret_fixup($$)
{
    my ($ref_tmprow,$elements) = @_;
    my ($x);

    print "SQL call returned: " if $debug;
    for($x = 0; $x <= $elements; $x++)
    {
        ${$ref_tmprow}[$x] = "" unless(${$ref_tmprow}[$x]);
        print "[".${$ref_tmprow}[$x]."] " if $debug;
    }
    print "\n\n" if $debug;
}


sub opt_db()
{
    my $table;

    # MySQL
    if($global_driver eq "mysql")
    {
        print "Start table optimization for MySQL at: ".
              `$MYDCMD`;

        foreach $table (@tables)
        {
            print "Optimizing table [$table] at ".
                  `$MYDCMD` if $debug;
            $dbh->do("OPTIMIZE TABLE $table");
        }

        print " Stop table optimization for MySQL at: ".
              `$MYDCMD` . "\n";
    }

    # Optimize other db types here
}

